"""EcoTrack AI - FastAPI backend powered by NVIDIA Nemotron on Nebius Token Factory."""
from __future__ import annotations

import json
import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from . import db, demo, llm, prompts
from .routing import plan_route

STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "static")

VALID_CATEGORIES = {"recyclable", "organic", "hazardous", "e-waste", "general"}
VALID_BINS = {"blue", "green", "red", "yellow", "black"}


@asynccontextmanager
async def lifespan(_: FastAPI):
    db.init()
    yield


app = FastAPI(title="EcoTrack AI", version="1.0.0", lifespan=lifespan)


class ClassifyIn(BaseModel):
    text: str = Field(..., min_length=2, max_length=300, description="Describe the waste item")
    log: bool = True


class BinIn(BaseModel):
    name: str
    lat: float
    lon: float
    fill_pct: float = Field(..., ge=0, le=100)
    hazardous: bool = False


class RouteIn(BaseModel):
    depot_lat: float
    depot_lon: float
    bins: list[BinIn]
    min_fill: float = 60.0


def _normalise(d: dict, original: str) -> dict:
    """Validate/repair model output so the UI never breaks on odd replies."""
    cat = str(d.get("category", "general")).lower()
    if cat not in VALID_CATEGORIES:
        cat = "general"
    b = str(d.get("bin", "black")).lower()
    if b not in VALID_BINS:
        b = {"recyclable": "blue", "organic": "green", "hazardous": "red", "e-waste": "yellow"}.get(cat, "black")
    steps = d.get("disposal_steps") or []
    if not isinstance(steps, list):
        steps = [str(steps)]
    try:
        hazard = max(0, min(3, int(d.get("hazard_level", 0))))
    except (TypeError, ValueError):
        hazard = 0
    try:
        co2 = max(0.0, float(d.get("co2e_saved_kg", 0)))
    except (TypeError, ValueError):
        co2 = 0.0
    return {
        "item": str(d.get("item") or original)[:80],
        "category": cat,
        "material": str(d.get("material", "unknown"))[:80],
        "bin": b,
        "disposal_steps": [str(s) for s in steps][:5],
        "hazard_level": hazard,
        "co2e_saved_kg": round(co2, 2),
        "eco_tip": str(d.get("eco_tip", ""))[:200],
    }


@app.get("/api/health")
def health():
    return {
        "status": "ok",
        "mode": "demo (offline keyword fallback)" if llm.DEMO_MODE else "live (Nemotron on Nebius Token Factory)",
        "fast_model": llm.FAST_MODEL,
        "reason_model": llm.REASON_MODEL,
    }


@app.post("/api/classify")
def classify(body: ClassifyIn):
    try:
        raw = demo.classify(body.text) if llm.DEMO_MODE else llm.chat_json(
            llm.FAST_MODEL, prompts.CLASSIFY_SYSTEM, f"Waste item: {body.text}"
        )
    except Exception as e:  # network/model/JSON errors -> clear message
        raise HTTPException(status_code=502, detail=f"Model call failed: {type(e).__name__}: {e}")
    result = _normalise(raw, body.text)
    result["model"] = "demo" if llm.DEMO_MODE else llm.FAST_MODEL
    if body.log:
        result["log_id"] = db.add_entry(
            result["item"], result["category"], result["bin"], result["hazard_level"], result["co2e_saved_kg"]
        )
    return result


@app.get("/api/log")
def get_log(limit: int = 50):
    return db.recent(min(max(limit, 1), 200))


@app.get("/api/stats")
def get_stats(days: int = 7):
    return db.stats(min(max(days, 1), 365))


@app.post("/api/report")
def report(days: int = 7):
    s = db.stats(min(max(days, 1), 365))
    if s["total_items"] == 0:
        raise HTTPException(status_code=400, detail="No items logged yet. Classify a few items first.")
    try:
        text = demo.report(s) if llm.DEMO_MODE else llm.chat(
            llm.REASON_MODEL, prompts.REPORT_SYSTEM, json.dumps(s), max_tokens=800
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Model call failed: {type(e).__name__}: {e}")
    return {"stats": s, "report_markdown": text, "model": "demo" if llm.DEMO_MODE else llm.REASON_MODEL}


@app.post("/api/route")
def route(body: RouteIn):
    stops = plan_route([b.model_dump() for b in body.bins], (body.depot_lat, body.depot_lon), body.min_fill)
    if not stops:
        return {"route": [], "briefing_markdown": "No bins need collection right now.", "model": None}
    try:
        text = demo.route_brief(stops) if llm.DEMO_MODE else llm.chat(
            llm.REASON_MODEL, prompts.ROUTE_SYSTEM, json.dumps(stops), max_tokens=700
        )
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Model call failed: {type(e).__name__}: {e}")
    return {"route": stops, "briefing_markdown": text, "model": "demo" if llm.DEMO_MODE else llm.REASON_MODEL}


@app.post("/api/reset")
def reset():
    db.clear()
    return {"ok": True}


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")


@app.get("/")
def index():
    return FileResponse(os.path.join(STATIC_DIR, "index.html"))
