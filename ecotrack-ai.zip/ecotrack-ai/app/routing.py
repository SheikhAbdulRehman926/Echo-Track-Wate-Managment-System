"""Deterministic pickup prioritisation. The LLM only *explains* the plan;
it never decides the order, so results are reproducible and auditable."""
from __future__ import annotations

from math import asin, cos, radians, sin, sqrt


def haversine_km(a: tuple[float, float], b: tuple[float, float]) -> float:
    lat1, lon1, lat2, lon2 = map(radians, (*a, *b))
    h = sin((lat2 - lat1) / 2) ** 2 + cos(lat1) * cos(lat2) * sin((lon2 - lon1) / 2) ** 2
    return 6371 * 2 * asin(sqrt(h))


def priority(fill_pct: float, hazardous: bool, dist_km: float) -> float:
    """Higher = collect sooner. Fill level dominates, hazard adds urgency,
    distance from the current stop is a mild penalty."""
    return round(0.65 * fill_pct + (25 if hazardous else 0) - 2.0 * dist_km, 2)


def plan_route(bins: list[dict], depot: tuple[float, float], min_fill: float = 60.0) -> list[dict]:
    """Greedy nearest-priority route over bins at/above min_fill (or hazardous)."""
    todo = [b for b in bins if b["fill_pct"] >= min_fill or b.get("hazardous")]
    route: list[dict] = []
    here = depot
    while todo:
        scored = []
        for b in todo:
            d = haversine_km(here, (b["lat"], b["lon"]))
            scored.append((priority(b["fill_pct"], bool(b.get("hazardous")), d), d, b))
        scored.sort(key=lambda t: -t[0])
        score, d, best = scored[0]
        route.append({**best, "priority": score, "leg_km": round(d, 2)})
        here = (best["lat"], best["lon"])
        todo.remove(best)
    return route
