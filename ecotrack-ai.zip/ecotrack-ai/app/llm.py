"""Thin client for NVIDIA Nemotron models served on Nebius Token Factory.

Token Factory exposes an OpenAI-compatible API, so we use the official
`openai` SDK pointed at the Nebius base URL.

Two model "tiers" are used (as the hackathon track suggests):
  * FAST_MODEL    - small/fast Nemotron for everyday, high-frequency calls
                    (waste classification).
  * REASON_MODEL  - larger Nemotron for heavier reasoning
                    (weekly sustainability report, route plan narrative).
"""
from __future__ import annotations

import json
import os
import re
from typing import Any

from openai import OpenAI

BASE_URL = os.getenv("NEBIUS_BASE_URL", "https://api.tokenfactory.nebius.com/v1/")
API_KEY = os.getenv("NEBIUS_API_KEY", "")

# Copy exact IDs from the Token Factory model catalog (they carry the "nvidia/" prefix).
FAST_MODEL = os.getenv("FAST_MODEL", "nvidia/Nemotron-3_5-Lightning")
REASON_MODEL = os.getenv("REASON_MODEL", "nvidia/Nemotron-3_5-Lightning")

# DEMO_MODE=1 lets the UI run without an API key (clearly labelled in the UI).
DEMO_MODE = os.getenv("DEMO_MODE", "0") == "1" or not API_KEY

_client: OpenAI | None = None


def client() -> OpenAI:
    global _client
    if _client is None:
        _client = OpenAI(base_url=BASE_URL, api_key=API_KEY)
    return _client


_THINK_RE = re.compile(r"<think>.*?</think>", re.DOTALL | re.IGNORECASE)
_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.IGNORECASE)


def extract_json(text: str) -> dict[str, Any]:
    """Pull a JSON object out of a model reply (handles <think> and code fences)."""
    text = _THINK_RE.sub("", text).strip()
    text = _FENCE_RE.sub("", text).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        start, end = text.find("{"), text.rfind("}")
        if start != -1 and end > start:
            return json.loads(text[start : end + 1])
        raise


def chat(model: str, system: str, user: str, *, temperature: float = 0.2,
         max_tokens: int = 900) -> str:
    resp = client().chat.completions.create(
        model=model,
        messages=[
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
        temperature=temperature,
        max_tokens=max_tokens,
    )
    return _THINK_RE.sub("", resp.choices[0].message.content or "").strip()


def chat_json(model: str, system: str, user: str, *, max_tokens: int = 700) -> dict[str, Any]:
    raw = chat(model, system, user, temperature=0.1, max_tokens=max_tokens)
    return extract_json(raw)
