"""Tiny SQLite store for waste log entries."""
from __future__ import annotations

import os
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone

DB_PATH = os.getenv("ECOTRACK_DB", "ecotrack.db")


@contextmanager
def conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    try:
        yield c
        c.commit()
    finally:
        c.close()


def init() -> None:
    with conn() as c:
        c.execute(
            """CREATE TABLE IF NOT EXISTS waste_log (
                 id INTEGER PRIMARY KEY AUTOINCREMENT,
                 ts TEXT NOT NULL,
                 item TEXT NOT NULL,
                 category TEXT NOT NULL,
                 bin TEXT NOT NULL,
                 hazard_level INTEGER NOT NULL DEFAULT 0,
                 co2e_saved_kg REAL NOT NULL DEFAULT 0
               )"""
        )


def add_entry(item: str, category: str, bin_: str, hazard: int, co2e: float,
              ts: datetime | None = None) -> int:
    ts = ts or datetime.now(timezone.utc)
    with conn() as c:
        cur = c.execute(
            "INSERT INTO waste_log (ts,item,category,bin,hazard_level,co2e_saved_kg) VALUES (?,?,?,?,?,?)",
            (ts.isoformat(), item, category, bin_, hazard, co2e),
        )
        return int(cur.lastrowid)


def recent(limit: int = 50) -> list[dict]:
    with conn() as c:
        rows = c.execute("SELECT * FROM waste_log ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    return [dict(r) for r in rows]


def stats(days: int = 7) -> dict:
    since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    with conn() as c:
        rows = c.execute("SELECT * FROM waste_log WHERE ts >= ?", (since,)).fetchall()
    rows = [dict(r) for r in rows]
    by_cat: dict[str, int] = {}
    items: dict[str, int] = {}
    for r in rows:
        by_cat[r["category"]] = by_cat.get(r["category"], 0) + 1
        items[r["item"]] = items.get(r["item"], 0) + 1
    total = len(rows)
    recyclable_like = by_cat.get("recyclable", 0) + by_cat.get("organic", 0) + by_cat.get("e-waste", 0)
    return {
        "period_days": days,
        "total_items": total,
        "by_category": by_cat,
        "top_items": sorted(items.items(), key=lambda kv: -kv[1])[:5],
        "hazardous_items": by_cat.get("hazardous", 0),
        "diversion_rate_pct": round(100 * recyclable_like / total, 1) if total else 0.0,
        "co2e_saved_kg": round(sum(r["co2e_saved_kg"] for r in rows), 2),
    }


def clear() -> None:
    with conn() as c:
        c.execute("DELETE FROM waste_log")
