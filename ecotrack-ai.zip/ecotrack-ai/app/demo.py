"""Offline keyword fallback so the UI and tests run without an API key.
This is NOT the submission path: with NEBIUS_API_KEY set, Nemotron does the work."""
from __future__ import annotations

RULES = [
    (("battery", "batteries", "lithium"), dict(category="hazardous", material="lithium/alkaline cell", bin="red", hazard_level=3, co2e_saved_kg=0.4)),
    (("phone", "charger", "laptop", "cable", "headphone", "electronic"), dict(category="e-waste", material="mixed electronics", bin="yellow", hazard_level=2, co2e_saved_kg=2.1)),
    (("paint", "chemical", "pesticide", "bleach", "bulb", "syringe"), dict(category="hazardous", material="chemical", bin="red", hazard_level=3, co2e_saved_kg=0.3)),
    (("banana", "peel", "food", "apple", "vegetable", "tea", "coffee", "leftover", "egg"), dict(category="organic", material="food scraps", bin="green", hazard_level=0, co2e_saved_kg=0.5)),
    (("bottle", "can", "tin", "paper", "cardboard", "newspaper", "glass", "jar", "plastic"), dict(category="recyclable", material="plastic/paper/glass/metal", bin="blue", hazard_level=0, co2e_saved_kg=0.8)),
]


def classify(text: str) -> dict:
    t = text.lower()
    for words, data in RULES:
        if any(w in t for w in words):
            return {
                "item": text.strip()[:60],
                "disposal_steps": ["Empty and rinse the item if needed", f"Place it in the {data['bin']} bin"],
                "eco_tip": "Buy less packaging and reuse where you can.",
                **data,
            }
    return {
        "item": text.strip()[:60], "category": "general", "material": "mixed", "bin": "black",
        "disposal_steps": ["Place in the general waste bin"], "hazard_level": 0,
        "co2e_saved_kg": 0.0, "eco_tip": "Check whether a repair or reuse option exists first.",
    }


def report(stats: dict) -> str:
    return (
        f"**Headline:** {stats['total_items']} items logged; diversion rate {stats['diversion_rate_pct']}%.\n\n"
        "_Demo mode: set NEBIUS_API_KEY to get a Nemotron-written analysis._"
    )


def route_brief(route: list[dict]) -> str:
    lines = [f"{i}. **{r['name']}** - {r['fill_pct']:.0f}% full" for i, r in enumerate(route, 1)]
    return "_Demo mode: set NEBIUS_API_KEY for a Nemotron dispatcher briefing._\n\n" + "\n".join(lines)
