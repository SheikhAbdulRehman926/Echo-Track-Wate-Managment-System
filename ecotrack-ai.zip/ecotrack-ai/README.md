# EcoTrack AI

> Smart waste sorting, sustainability reporting and pickup routing, powered by **NVIDIA Nemotron** models served on **Nebius Token Factory**.

**Hackathon:** Nebius x NVIDIA Global AI Hackathon &middot; **Track:** Best Apps and Agents &middot; **License:** MIT

## What it does

| Feature | Model tier | What happens |
|---|---|---|
| **Waste sorting** | Fast Nemotron (`FAST_MODEL`) | Describe an item in plain words. The model returns category, bin colour, disposal steps, hazard level (0-3) and CO2e saved, as validated JSON. |
| **Weekly sustainability report** | Larger Nemotron (`REASON_MODEL`) | Your logged items are aggregated (diversion rate, hotspots, CO2e) and the model writes a short action plan grounded only in those numbers. |
| **Smart pickup routing** | Deterministic algorithm + Nemotron | Bin order is computed by a transparent priority formula (fill level, hazard, distance). Nemotron only writes the dispatcher briefing and cannot reorder stops, so results are reproducible. |

## How NVIDIA Nemotron and Nebius Token Factory are used

- All language-model calls go through Nebius Token Factory's OpenAI-compatible API (`https://api.tokenfactory.nebius.com/v1/`) using the standard `openai` SDK (`app/llm.py`).
- Two tiers follow the track guidance: a small/fast Nemotron model for high-frequency classification, and a larger Nemotron model for report writing and routing briefings. Both are set with environment variables, so you can swap models without code changes.
- Token Factory's hosted inference removes the need to manage GPUs: the whole app is a thin FastAPI service plus an HTML page.
- Model output is never trusted blindly: `app/main.py::_normalise` validates and repairs every classification (allowed categories/bins, clamped hazard level), and `llm.extract_json` handles reasoning tags and code fences.

## Quick start

```bash
git clone <your-repo-url> ecotrack-ai && cd ecotrack-ai
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env        # then edit .env: add NEBIUS_API_KEY and model IDs
export $(grep -v '^#' .env | xargs)                    # Windows PowerShell: set each variable with $Env:NAME="value"

uvicorn app.main:app --reload --port 8000
# open http://localhost:8000
```

1. Create a key at <https://tokenfactory.nebius.com> (API keys page).
2. Copy exact model IDs (they start with `nvidia/`) from the Token Factory catalog into `FAST_MODEL` and `REASON_MODEL`.
3. The badge at the top of the UI shows **live (Nemotron on Nebius Token Factory)** when the key is active. Without a key the app falls back to an offline keyword demo mode, which exists only for UI testing.

## API

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/classify` | `{ "text": "used AA batteries" }` -> category, bin, steps, hazard, CO2e |
| GET | `/api/log`, `/api/stats` | Recent entries and aggregate statistics |
| POST | `/api/report?days=7` | Nemotron-written sustainability report |
| POST | `/api/route` | Priority route + dispatcher briefing |
| GET | `/api/health` | Mode and configured models |

## Tests

```bash
python -m pytest -q
```

Tests run in demo mode (no network) and cover JSON extraction, output repair, route determinism and the full API flow.

## Deploy (demo URL)

Any host that runs a Python web service works (Render, Railway, Fly.io, Hugging Face Spaces via Docker, or Nebius Serverless Endpoints with the included `Dockerfile`).
Set `NEBIUS_API_KEY`, `FAST_MODEL`, `REASON_MODEL` as environment variables on the host. Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`.

## Project structure

```
app/main.py      FastAPI routes, output validation
app/llm.py       Nebius Token Factory client (OpenAI SDK), JSON extraction
app/prompts.py   System prompts
app/routing.py   Deterministic pickup prioritisation
app/db.py        SQLite log + statistics
app/demo.py      Offline fallback (UI testing only)
static/index.html  Single-page UI
tests/           pytest suite
```

## Limitations and next steps

- Classification is text-based; a vision-capable NVIDIA model could classify photos.
- CO2e figures are rough model estimates, not certified emissions data.
- Local disposal rules vary by city; the prompt can be extended with municipal rules (RAG).
- Next: Nebius Serverless Jobs for scheduled weekly reports, multi-user accounts, live IoT fill-level sensors.

## License

MIT, see [LICENSE](LICENSE).
