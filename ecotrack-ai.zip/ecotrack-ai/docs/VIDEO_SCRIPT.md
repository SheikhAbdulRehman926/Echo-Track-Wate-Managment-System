# 3-minute demo video script (target 2:40)

Record with any screen recorder (OBS, Loom, Windows Game Bar, QuickTime). Browser at 100% zoom, app running with your **live** API key so the badge shows green "live (Nemotron on Nebius Token Factory)". Upload to YouTube as **Public**.

| Time | Screen | Say |
|---|---|---|
| 0:00-0:15 | Title slide or app header | "Hi, I'm [name]. This is EcoTrack AI, a waste-management agent built for the Nebius x NVIDIA hackathon. It runs on NVIDIA Nemotron models served through Nebius Token Factory." |
| 0:15-0:35 | Hover the green live badge | "The badge confirms live mode: every answer you will see comes from Nemotron on Token Factory, through its OpenAI-compatible API." |
| 0:35-1:10 | Classify "used AA batteries", then "old phone charger" | "Step one: sorting. I describe an item in plain words and a fast Nemotron model returns the bin, safe disposal steps, hazard level and CO2 impact as structured JSON. Batteries go to the red hazardous bin; the charger is e-waste." |
| 1:10-1:25 | Click 2 more example chips | "Everything is logged, so the dashboard updates live." |
| 1:25-2:00 | Click Generate report | "Step two: a larger Nemotron model reads the aggregated statistics and writes a weekly action plan. It is told to use only the real figures, so it does not invent data." |
| 2:00-2:30 | Click Plan route | "Step three: routing. The order is computed by a transparent formula using fill level, hazard and distance, so it is reproducible. Nemotron writes the dispatcher briefing but cannot reorder stops. AI where judgement helps, deterministic code where safety matters." |
| 2:30-2:50 | Show GitHub repo page with MIT license, then README | "The code is open source under MIT, with a README, tests, and a Dockerfile. Using Token Factory meant no GPU setup: one API key and two model IDs. Thanks for watching." |

## Recording tips
- Do a dry run first; keep under 3:00 (judges may stop watching after 3 minutes).
- Pre-type nothing: show the real latency, it is a strength.
- Title the video "EcoTrack AI - Nebius x NVIDIA Global AI Hackathon" and mention Nemotron + Token Factory in the description.
