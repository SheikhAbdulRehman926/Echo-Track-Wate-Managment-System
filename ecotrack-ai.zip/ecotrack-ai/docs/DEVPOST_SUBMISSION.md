# Devpost submission text (copy and paste)

**Track:** Best Apps and Agents

## Project name
EcoTrack AI

## Tagline (one line)
An AI waste-management agent that sorts items, writes sustainability reports and plans pickup routes, powered by NVIDIA Nemotron on Nebius Token Factory.

## Inspiration / why
Wrong-bin disposal contaminates recycling, and organisations lack simple tools to see where their waste goes or which bins to collect first. I wanted something a household, school or city team could use in seconds, without sending data to a closed model.

## What it does
- **Sort:** type "used AA batteries" and get the right bin, safe disposal steps, hazard level and estimated CO2e saved.
- **Report:** logged items are aggregated and a larger Nemotron model writes a weekly action plan grounded in the real numbers.
- **Route:** bins are prioritised by a deterministic formula (fill level, hazard, distance); Nemotron writes the dispatcher briefing and cannot change the order.

## How I built it
- FastAPI backend, SQLite log, single-page HTML UI.
- NVIDIA Nemotron models called through Nebius Token Factory's OpenAI-compatible API.
- Two model tiers: a fast model for everyday classification, a larger one for reasoning-heavy reports and briefings (configurable by environment variable).
- Guardrails: strict JSON prompts, output validation and repair, hazard-conservative prompting, and a deterministic router so the LLM never makes safety-critical ordering decisions.

## How I used NVIDIA Nemotron and Nebius
- NVIDIA Nemotron models: all classification, report and briefing generation.
- Nebius Token Factory: hosted inference through one API key, with no GPU setup. [Add: measured latency / cost observations from your own testing.]
- [Optional, only if you really use them: Nebius Serverless Endpoints for hosting the app.]

## Challenges
Models sometimes wrap JSON in code fences or reasoning tags, so I added a robust extractor and a validator that repairs out-of-range values.

## Accomplishments
A complete, tested, deployable app (6 automated tests) with a clear separation between AI judgement and deterministic logic.

## What I learned
[Write 2-3 honest sentences from your own experience building it.]

## What's next
Photo-based sorting with an NVIDIA vision model, municipal rules via RAG, scheduled weekly reports with Nebius Serverless Jobs, live IoT fill sensors.

## Built with
Python, FastAPI, SQLite, NVIDIA Nemotron, Nebius Token Factory, OpenAI SDK, HTML/JS

## Links to fill in
- Demo URL: [your deployed URL]
- Code repo: [public GitHub URL, LICENSE visible at top]
- Video: [public YouTube URL, 3 minutes or less]

## Pre-existing work statement (required, because EcoTrack existed before)
EcoTrack Waste Management System existed before the Submission Period as [describe in one line what it was, e.g. a basic web app for logging waste]. During the Submission Period I significantly updated it by: (1) adding an AI classification service using NVIDIA Nemotron on Nebius Token Factory, (2) adding an LLM-written sustainability report pipeline, (3) adding deterministic pickup routing with an LLM dispatcher briefing, (4) adding output validation, tests and a new UI. [Edit so it is accurate for what you really did.]

## Feedback on Nebius Token Factory / NVIDIA tools (required)
Write this from your own experience. Suggested points to comment on, with your real answers:
- Onboarding: how long from sign-up to first successful API call? Was the model ID format clear?
- Reliability and latency of the fast vs larger Nemotron model.
- JSON-following quality; did you need retries or repair?
- Documentation gaps, pricing/credit clarity, and features you wished for.
