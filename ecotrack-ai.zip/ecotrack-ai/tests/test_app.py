import os
import tempfile

os.environ["DEMO_MODE"] = "1"
os.environ["ECOTRACK_DB"] = os.path.join(tempfile.mkdtemp(), "test.db")

from fastapi.testclient import TestClient  # noqa: E402

from app import llm  # noqa: E402
from app.main import _normalise, app  # noqa: E402
from app.routing import plan_route  # noqa: E402


def test_extract_json_handles_think_and_fences():
    raw = '<think>hmm</think>\n```json\n{"a": 1}\n```'
    assert llm.extract_json(raw) == {"a": 1}


def test_extract_json_finds_object_in_prose():
    assert llm.extract_json('Sure! {"x": 2} hope that helps') == {"x": 2}


def test_normalise_repairs_bad_model_output():
    out = _normalise({"category": "weird", "bin": "purple", "hazard_level": "9", "co2e_saved_kg": "x"}, "thing")
    assert out["category"] == "general" and out["bin"] == "black"
    assert out["hazard_level"] == 3 and out["co2e_saved_kg"] == 0.0


def test_route_is_deterministic_and_filters_low_fill():
    bins = [
        {"name": "A", "lat": 24.86, "lon": 67.00, "fill_pct": 30, "hazardous": False},
        {"name": "B", "lat": 24.87, "lon": 67.01, "fill_pct": 90, "hazardous": False},
        {"name": "C", "lat": 24.88, "lon": 67.02, "fill_pct": 50, "hazardous": True},
    ]
    r1 = plan_route(bins, (24.86, 67.00))
    r2 = plan_route(bins, (24.86, 67.00))
    assert [s["name"] for s in r1] == [s["name"] for s in r2]
    assert "A" not in [s["name"] for s in r1] and {"B", "C"} == {s["name"] for s in r1}


def test_api_end_to_end_demo_mode():
    with TestClient(app) as c:
        assert c.get("/api/health").json()["status"] == "ok"
        c.post("/api/reset")
        r = c.post("/api/classify", json={"text": "used AA batteries"}).json()
        assert r["category"] == "hazardous" and r["bin"] == "red"
        c.post("/api/classify", json={"text": "banana peel"})
        s = c.get("/api/stats").json()
        assert s["total_items"] == 2
        assert "report_markdown" in c.post("/api/report").json()
        route = c.post("/api/route", json={
            "depot_lat": 24.86, "depot_lon": 67.0,
            "bins": [{"name": "X", "lat": 24.87, "lon": 67.01, "fill_pct": 80}]}).json()
        assert route["route"][0]["name"] == "X"
        assert c.get("/").status_code == 200


def test_report_requires_data():
    with TestClient(app) as c:
        c.post("/api/reset")
        assert c.post("/api/report").status_code == 400
